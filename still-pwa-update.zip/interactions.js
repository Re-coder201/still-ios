/* Review history and application-owned reading selection. No native text ranges. */
function animateReviewTurn(direction){const wrap=app.querySelector('.review-wrap');if(!wrap)return;wrap.classList.add(direction==='back'?'review-enter-back':'review-enter-forward');}
function reviewSwipeDirection(dx,dy){if(Math.abs(dx)<72||Math.abs(dx)<Math.abs(dy)*1.6)return null;return dx<0?'back':'forward';}
let reviewSwipe=null,reviewSwipeAt=0;
document.addEventListener('pointerdown',event=>{
 if(tab!=='review'||!session||overlay.children.length||event.isPrimary===false||event.button>0)return;
 if(event.target.closest('button,a,input,textarea,[data-action]')&&!event.target.closest('.review-card .token'))return;
 if(!event.target.closest('.review-card,.review-wrap'))return;
 reviewSwipe={id:event.pointerId,x:event.clientX,y:event.clientY,at:Date.now(),index:session.index,active:session};
},{passive:true});
document.addEventListener('pointerup',event=>{
 const gesture=reviewSwipe;if(!gesture||event.pointerId!==gesture.id)return;reviewSwipe=null;
 if(tab!=='review'||session!==gesture.active||session.index!==gesture.index||overlay.children.length||Date.now()-gesture.at>1500||Date.now()-reviewSwipeAt<300)return;
 const direction=reviewSwipeDirection(event.clientX-gesture.x,event.clientY-gesture.y);if(!direction)return;
 // The requested gesture is left = previous; right only revisits existing history.
 reviewSwipeAt=Date.now();if(direction==='back')previousReview();else if(session.index<session.deck.length-1)next();
},{passive:true});
document.addEventListener('pointercancel',()=>{reviewSwipe=null;},{passive:true});
document.addEventListener('click',event=>{if(Date.now()-reviewSwipeAt<350&&event.target.closest('.review-wrap')){event.preventDefault();event.stopImmediatePropagation();}},true);

function readingSelectionFragments(article,a,b){
 const points=[a,b].sort((x,y)=>x.paragraph-y.paragraph||x.start-y.start),first=points[0],last=points[1],fragments=[];
 for(let index=first.paragraph;index<=last.paragraph;index++){
  const text=article.paragraphs[index];if(typeof text!=='string')continue;
  const start=index===first.paragraph?Math.max(0,first.start):0,end=index===last.paragraph?Math.min(text.length,last.end):text.length;
  if(end>start&&text.slice(start,end).trim())fragments.push({paragraph:index,start,end,text:text.slice(start,end)});
 }
 return fragments;
}
const CustomReadingSelection=(()=>{
 let gesture=null,holdTimer=null,paintFrame=null,layer=null;
 function clearPaint(){if(paintFrame!==null)cancelAnimationFrame(paintFrame);paintFrame=null;layer?.remove();layer=null;}
 function clear(){clearTimeout(holdTimer);gesture=null;clearPaint();}
 function paragraphPoint(token){
  const p=token?.closest('.reading-paragraph'),block=p?.closest('.paragraph-block');if(!p||!block)return null;
  const prefix=document.createRange();prefix.selectNodeContents(p);prefix.setEndBefore(token);
  const start=prefix.toString().length;
  return {paragraph:Number(block.dataset.paragraph),start,end:start+token.textContent.length};
 }
 function tokenAt(x,y,fallback){
  const hit=document.elementFromPoint?.(x,y),direct=hit?.closest('.reading-paragraph .token');if(direct)return direct;
  if(hit?.closest('#reading-selection-tools')||hit?.closest('.bottom-nav'))return fallback;
  let best=null,distance=Infinity;
  for(const token of app.querySelectorAll('.reading-paragraph .token'))for(const r of token.getClientRects()){
   const dx=Math.max(r.left-x,0,x-r.right),dy=Math.max(r.top-y,0,y-r.bottom),score=dx*dx+dy*dy*4;
   if(score<distance){distance=score;best=token;}
  }
  return best||fallback;
 }
 function textPoint(p,offset){const walker=document.createTreeWalker(p,NodeFilter.SHOW_TEXT);let node,last=null,left=offset;while(node=walker.nextNode()){last=node;if(left<=node.textContent.length)return [node,left];left-=node.textContent.length;}return last?[last,last.textContent.length]:[p,0];}
 function rectsFor(fragment){
  const p=app.querySelector('.paragraph-block[data-paragraph="'+fragment.paragraph+'"] .reading-paragraph');if(!p)return [];
  const range=document.createRange(),a=textPoint(p,fragment.start),b=textPoint(p,fragment.end);range.setStart(...a);range.setEnd(...b);return typeof range.getClientRects==='function'?[...range.getClientRects()].filter(r=>r.width&&r.height):[];
 }
 function paint(){
  paintFrame=null;if(!readingSelection?.custom||tab!=='reading'){clearPaint();return;}
  const rects=readingSelection.fragments.flatMap(rectsFor);if(!rects.length)return;
  if(!layer?.isConnected){layer=document.createElement('div');layer.id='reading-custom-selection';const rectangles=document.createElement('div');rectangles.className='reading-selection-rects';layer.appendChild(rectangles);document.body.appendChild(layer);}
  const rectangles=layer.querySelector('.reading-selection-rects');rectangles.replaceChildren();
  for(const r of rects){const rect=document.createElement('i');rect.className='reading-selection-rect';Object.assign(rect.style,{left:r.left+'px',top:r.top+'px',width:r.width+'px',height:r.height+'px'});rectangles.appendChild(rect);}
  for(const [edge,r,x]of [['start',rects[0],rects[0].left],['end',rects.at(-1),rects.at(-1).right]]){
   let handle=layer.querySelector('[data-selection-handle="'+edge+'"]');if(!handle){handle=document.createElement('button');handle.type='button';handle.className='reading-selection-handle';handle.dataset.selectionHandle=edge;handle.setAttribute('aria-label',edge==='start'?'拖动调整选区起点':'拖动调整选区终点');layer.appendChild(handle);}Object.assign(handle.style,{left:x+'px',top:r.bottom+'px'});
  }
 }
 function schedulePaint(){if(paintFrame===null)paintFrame=requestAnimationFrame(paint);}
 function setRange(a,b){
  const article=currentReadingArticle();if(!article)return;
  const fragments=readingSelectionFragments(article,a,b);if(!fragments.length)return;
  const old=readingSelection;readingSelection={custom:true,article:readingKey(article),fragments,text:fragments.map(f=>f.text).join('\n\n'),color:old?.color||state.highlightColor,anchor:a,focus:b};
  if(old?.text!==readingSelection.text)selectionPaletteOpen=false;
  selectionLocked=false;lastReadingDragAt=Date.now();window.getSelection()?.removeAllRanges();showReadingSelectionTools();paint();
 }
 function activate(){if(!gesture||gesture.active)return;gesture.active=true;readingGesture=null;clearTimeout(selectionTimer);setRange(gesture.anchor,gesture.focus);}
 function start(target,x,y,pointer){
  if(tab!=='reading'||overlay.children.length)return;
  const handle=target.closest('[data-selection-handle]');
  if(handle&&readingSelection?.custom){
   const first=readingSelection.fragments[0],last=readingSelection.fragments.at(-1),a={paragraph:first.paragraph,start:first.start,end:first.start+1},b={paragraph:last.paragraph,start:last.end-1,end:last.end};
   gesture={pointer,x,y,active:true,anchor:handle.dataset.selectionHandle==='start'?b:a,focus:handle.dataset.selectionHandle==='start'?a:b,token:null};readingGesture=null;return;
  }
  const token=target.closest('.reading-paragraph .token');if(!token)return;
  const point=paragraphPoint(token);if(!point)return;
  hideReadingSelection(true);gesture={pointer,x,y,active:false,anchor:point,focus:point,token};holdTimer=setTimeout(activate,330);
 }
 function move(x,y,event){
  if(!gesture)return;const dx=x-gesture.x,dy=y-gesture.y;
  if(!gesture.active){
   if(Math.hypot(dx,dy)<9)return;
   if(Math.abs(dx)<Math.abs(dy)*1.35){clear();readingGesture=null;return;}
   activate();
  }
  if(event.cancelable)event.preventDefault();
  const token=tokenAt(x,y,gesture.token),point=paragraphPoint(token);if(point){gesture.focus=point;setRange(gesture.anchor,point);}
  if(y<105)window.scrollBy({top:-12,behavior:'instant'});else if(y>window.innerHeight-240)window.scrollBy({top:12,behavior:'instant'});
 }
 function finish(event){
  if(!gesture)return;const active=gesture.active;clearTimeout(holdTimer);gesture=null;
  if(active){lastReadingDragAt=Date.now();readingGesture=null;if(event?.cancelable)event.preventDefault();event?.stopImmediatePropagation();schedulePaint();}
 }
 document.addEventListener('touchstart',event=>{if(event.touches.length!==1){clear();return;}const p=event.touches[0];start(event.target,p.clientX,p.clientY,'touch');},{capture:true,passive:true});
 document.addEventListener('touchmove',event=>{if(gesture?.pointer!=='touch')return;if(event.touches.length!==1){clear();return;}const p=event.touches[0];move(p.clientX,p.clientY,event);},{capture:true,passive:false});
 document.addEventListener('touchend',event=>{if(gesture?.pointer==='touch')finish(event);},{capture:true,passive:false});
 document.addEventListener('touchcancel',()=>{clearTimeout(holdTimer);gesture=null;readingGesture=null;schedulePaint();},{passive:true});
 document.addEventListener('pointerdown',event=>{if(event.pointerType==='touch'||event.button>0||event.isPrimary===false)return;start(event.target,event.clientX,event.clientY,event.pointerId);if(gesture&&event.cancelable)event.preventDefault();},true);
 document.addEventListener('pointermove',event=>{if(gesture?.pointer===event.pointerId)move(event.clientX,event.clientY,event);},{capture:true,passive:false});
 document.addEventListener('pointerup',event=>{if(gesture?.pointer===event.pointerId)finish(event);},true);
 document.addEventListener('contextmenu',event=>{if(event.target.closest('.reading-paragraph,#reading-selection-tools,#reading-custom-selection'))event.preventDefault();},true);
 document.addEventListener('selectstart',event=>{if(event.target.closest('.reading-paragraph'))event.preventDefault();},true);
 document.addEventListener('keydown',event=>{if(event.key==='Escape'&&readingSelection?.custom)hideReadingSelection(true);});
 window.addEventListener('scroll',schedulePaint,{passive:true});window.addEventListener('resize',schedulePaint,{passive:true});
 return {clear,busy:()=>!!gesture||!!readingSelection?.custom,setRange,paint,paragraphPoint};
})();
const originalSelectionHide=hideReadingSelection;
hideReadingSelection=function(clear=false){CustomReadingSelection.clear();originalSelectionHide(clear);};
const originalInteractionRender=render;
function interactionViewKey(){return [tab,current||'',detailFrom||'',tab==='reading'?JSON.stringify(readingState):''].join('|');}
let previousInteractionView=interactionViewKey();
render=function(){
 const changed=interactionViewKey()!==previousInteractionView;
 if(readingSelection?.custom)hideReadingSelection(true);
 originalInteractionRender();
 if(changed)app.querySelector('#main')?.classList.add('view-enter');
 previousInteractionView=interactionViewKey();
};
