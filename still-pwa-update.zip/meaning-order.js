/* Common usage priorities for frequent polysemous English words; stable order for other entries. */
const MEANING_POS_PRIORITIES={still:['adv','a','adj','conj','v','vt','vi','n'],well:['adv','a','adj','int','interj','n','v','vi'],just:['adv','a','adj'],even:['adv','a','adj','v','vt'],yet:['adv','conj'],only:['adv','a','adj','conj'],rather:['adv','int'],ever:['adv'],almost:['adv'],enough:['adv','a','adj','n'],quite:['adv'],like:['v','vt','vi','prep','conj','a','adj','n'],as:['conj','prep','adv','pron'],since:['prep','conj','adv'],before:['prep','conj','adv'],after:['prep','conj','adv','a'],while:['conj','n','v','vt'],that:['pron','conj','a','adj','adv'],this:['pron','a','adj','adv'],these:['pron','a','adj'],those:['pron','a','adj'],there:['adv','pron','n'],here:['adv','n'],then:['adv','a','adj','n'],so:['adv','conj','pron','n'],such:['a','adj','pron','adv'],both:['a','adj','pron','conj'],either:['a','adj','pron','adv','conj'],neither:['pron','a','adj','conj','adv'],some:['a','adj','pron','adv'],any:['a','adj','pron','adv'],each:['a','adj','pron','adv'],all:['a','adj','pron','adv','n'],can:['aux','modal','v','n'],could:['aux','modal','v'],will:['aux','modal','v','n'],would:['aux','modal','v'],may:['aux','modal','v','n'],might:['aux','modal','v','n'],must:['aux','modal','v','n'],should:['aux','modal','v'],ought:['aux','modal','v'],do:['aux','v','vt','vi','n'],have:['aux','v','vt','vi','n'],be:['aux','v','vi'],get:['v','vt','vi','n'],make:['v','vt','vi','n'],take:['v','vt','vi','n'],give:['v','vt','vi','n'],go:['vi','v','vt','n'],come:['vi','v','n'],say:['v','vt','vi','n'],find:['v','vt','vi','n'],seem:['vi','v'],become:['vi','v','vt'],know:['v','vt','vi','n'],think:['v','vt','vi','n'],feel:['v','vt','vi','n'],need:['v','vt','aux','modal','n'],help:['v','vt','vi','n'],keep:['v','vt','vi','n'],try:['v','vt','vi','n'],use:['n','v','vt','vi'],more:['a','adj','adv','n'],most:['a','adj','adv','n'],much:['a','adj','adv','n'],many:['a','adj','pron','n'],few:['a','adj','pron','n'],little:['a','adj','adv','n'],less:['a','adj','adv','prep'],least:['a','adj','adv','n'],other:['a','adj','pron'],another:['a','adj','pron'],next:['a','adj','adv','n','prep'],last:['a','adj','adv','n','v'],own:['a','adj','v','vt'],same:['a','adj','pron','adv'],long:['a','adj','adv','vi','v','n'],back:['adv','n','a','adj','v'],away:['adv','a','adj'],off:['adv','prep','a','adj','n'],over:['prep','adv','a','adj','n'],out:['adv','prep','a','adj','n'],up:['adv','prep','a','adj','n'],down:['adv','prep','a','adj','n'],near:['prep','a','adj','adv','v'],far:['adv','a','adj'],fast:['a','adj','adv','n','v'],hard:['a','adj','adv'],early:['a','adj','adv'],late:['a','adj','adv'],better:['a','adj','adv','n','v'],best:['a','adj','adv','n','v'],very:['adv','a','adj'],pretty:['adv','a','adj','n','v'],likely:['a','adj','adv'],sure:['a','adj','adv'],due:['a','adj','n','adv'],right:['a','adj','adv','n','v'],wrong:['a','adj','adv','n','v']};
function rankDictionaryMeanings(word,meanings){const priorities=MEANING_POS_PRIORITIES[word.toLowerCase()];const rank=entry=>{const technical=/^\s*\[(?:计|医|法|经|化|电|机|网络|生物|物|数|军)/.test(entry[1])?100:0;if(!Array.isArray(priorities))return technical;const poses=entry[0].toLowerCase().match(/[a-z]+/g)||[];const found=poses.map(p=>priorities.indexOf(p)).filter(n=>n>=0);return technical+(found.length?Math.min(...found):50);};return meanings.map((entry,index)=>({entry,index,rank:rank(entry)})).sort((a,b)=>a.rank-b.rank||a.index-b.index).map(item=>item.entry);}

// Brief entries are deliberately curated summaries, not the first rows of the full dictionary.
const COMMON_BRIEF_MEANINGS={
 still:[['adv.','仍然；还'],['adj.','静止的；安静的'],['conj.','然而；不过']],
 well:[['adv.','好；顺利地'],['adj.','健康的；身体好的'],['int.','嗯；好吧']],
 just:[['adv.','刚刚；仅仅；正好'],['adj.','公正的；合理的']],
 even:[['adv.','甚至；连；更加'],['adj.','平坦的；均匀的']],
 can:[['aux.','能；会；可以']],could:[['aux.','能；可以（can 的过去式，也用于委婉语气）']],
 will:[['aux.','将；会；愿意'],['n.','意愿；意志']],would:[['aux.','将会；愿意；会（用于假设或委婉语气）']],
 may:[['aux.','可能；可以']],might:[['aux.','可能；也许']],must:[['aux.','必须；一定']],should:[['aux.','应该；应当']],
 like:[['vt.','喜欢'],['prep.','像；如同']],
 while:[['conj.','当……时；而；虽然'],['n.','一会儿；一段时间']],
 spring:[['n.','春天；泉水；弹簧'],['vi.','跳跃；突然出现']],
 present:[['adj.','当前的；在场的'],['n.','现在；礼物'],['vt.','提出；展示；赠送']],
 mean:[['vt.','意思是；意味着；打算'],['adj.','刻薄的；吝啬的']],
 fine:[['adj.','好的；晴朗的；精细的'],['n.','罚款'],['vt.','处以罚款']],
 right:[['adj.','正确的；右边的'],['adv.','正确地；向右'],['n.','权利；右边']],
 left:[['adj.','左边的；剩余的'],['n.','左边'],['v.','离开；留下（leave 的过去式和过去分词）']],
 last:[['adj.','最后的；上一个的'],['vi.','持续；维持'],['adv.','最后；最近一次']],
 back:[['adv.','向后；回来'],['n.','背部；后面'],['adj.','后面的']],
 book:[['n.','书；书籍'],['vt.','预订；预约']],
 watch:[['v.','观看；注视；留意'],['n.','手表']],
 work:[['n.','工作；作品'],['v.','工作；起作用；运转']],
 study:[['n.','学习；研究'],['v.','学习；研究']],
 matter:[['n.','事情；问题；物质'],['vi.','要紧；有关系']],
 kind:[['n.','种类'],['adj.','友善的；体贴的']],
 sound:[['n.','声音'],['v.','听起来；发出声音'],['adj.','健全的；可靠的']],
 close:[['v.','关闭；结束'],['adj.','近的；亲密的'],['adv.','靠近地']],
 light:[['n.','光；灯'],['adj.','轻的；浅色的'],['v.','点燃；照亮']],
 fair:[['adj.','公平的；合理的'],['n.','展览会；集市']],
 second:[['num.','第二'],['n.','秒；第二名']],
 sentence:[['n.','句子；判决'],['vt.','判决；宣判']]
};
function briefDictionaryMeanings(word,meanings){
 const key=word.toLowerCase(),curated=COMMON_BRIEF_MEANINGS[key];
 if(Array.isArray(curated))return curated.map(entry=>entry.slice());
 const ordered=rankDictionaryMeanings(word,meanings);
 const common=ordered.filter(([,zh])=>!/^\s*[\[【]/.test(zh)&&!/(?:罕用|古语|古义|废语|冷僻)/.test(zh));
 // Keep specialist-only words meaningful, without mixing specialist rows into a general summary.
 const selected=(common.length?common:ordered).slice(0,2);
 return selected.map(([pos,zh])=>[pos,zh.split(/[;；,，]/).map(s=>s.trim()).filter(Boolean).slice(0,3).join('；')||zh]);
}
