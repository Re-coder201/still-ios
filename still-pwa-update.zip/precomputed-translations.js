/* Small static translation packs: no model, worker or inference on the phone. */
const ReadingTranslationLibrary=(()=>{
 const normal=text=>String(text).replace(/\s+/g,' ').trim();
 const hash=text=>{let value=2166136261;for(let i=0;i<text.length;i++){value^=text.charCodeAt(i);value=Math.imul(value,16777619);}return (value>>>0).toString(36);};
 let indexPromise;const packs=new Map(),pending=new Map();
 function unavailable(){const error=Error('本段译文尚未下载，请联网后再次展开，或在“安装与离线管理”中完成离线下载。');error.code='READING_TRANSLATION_DOWNLOAD';return error;}
 async function read(file){const controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),15000);try{const response=await fetch('./reading-translation-library/'+file+'.json',{signal:controller.signal});if(!response.ok)throw unavailable();const data=await response.json();if(!data||typeof data!=='object'||Array.isArray(data))throw unavailable();return data;}catch{throw unavailable();}finally{clearTimeout(timeout);}}
 async function index(){if(!indexPromise)indexPromise=read('index').catch(error=>{indexPromise=null;throw error;});return indexPromise;}
 async function pack(name){if(packs.has(name)){const hit=packs.get(name);packs.delete(name);packs.set(name,hit);return hit;}if(pending.has(name))return pending.get(name);const job=read(name).then(value=>{packs.set(name,value);while(packs.size>3)packs.delete(packs.keys().next().value);return value;}).finally(()=>pending.delete(name));pending.set(name,job);return job;}
 async function exact(input){const names=(await index())[hash(input)];if(!Array.isArray(names))return null;for(const name of names){if(!/^(cet[46]|postgrad[12])-20\d{2}$/.test(name))continue;const data=await pack(name);if(Object.prototype.hasOwnProperty.call(data,input)&&typeof data[input]?.zh==='string'&&data[input].zh.trim())return {text:input,...data[input]};}return null;}
 async function find(text){const input=normal(text);if(!input)return null;const hit=await exact(input);if(hit)return hit;if(typeof Intl.Segmenter!=='function')return null;const sentences=[...new Intl.Segmenter('en',{granularity:'sentence'}).segment(input)].map(s=>normal(s.segment)).filter(Boolean);if(sentences.length<2)return null;const results=[];for(const sentence of sentences){const result=await exact(sentence);if(!result)return null;results.push(result);}return {text:input,zh:results.map(result=>result.zh).join(''),source:results.some(result=>result.source.includes('机译'))?'预置离线机译 · 对应原句':'本地整理译文 · 对应原句'};}
 return {find};
})();
