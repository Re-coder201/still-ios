/* Full offline Chinese search. The index is lazy-loaded, so initial reading stays fast. */
(()=>{
 const han=value=>/[\u3400-\u9fff]/.test(value||'');
 const clean=value=>String(value||'').replace(/\s+/g,'').trim();
 let timer=0,request=0;
 function render(term,list,message=''){const input=document.querySelector('#search-input'),box=document.querySelector('#suggestions');if(!input||!box||clean(input.value)!==term)return;box.hidden=false;input.setAttribute('aria-expanded','true');box.innerHTML=list.length?list.map(w=>`<button class="suggestion" role="option" data-action="search-word" data-value="${esc(w.word)}"><strong>${esc(w.word)}</strong><span>${esc(w.brief[0]?.[1]||'')}</span><small>${icon('arrow')}</small></button>`).join(''):`<div class="no-results">${esc(message||'本地完整词库未找到对应释义')}</div>`;}
 async function search(value,focus=false){const term=clean(value);if(!han(term))return;const token=++request;render(term,[],'正在搜索完整本地词库…');try{const found=await OfflineDictionary.searchChinese(term,12);if(token!==request)return;const local=searchMatches(term),unique=new Map([...local,...found].map(word=>[word.word,word]));const list=[...unique.values()];render(term,list);if(focus&&list.length!==1)document.querySelector('.suggestion')?.focus();if(focus&&list.length===1)searchWord(list[0].word);}catch(error){if(token===request)render(term,[],'中文索引暂时无法读取，请稍后重试');}}
 document.addEventListener('input',event=>{if(event.target?.id!=='search-input')return;const value=event.target.value;if(!han(value))return;clearTimeout(timer);timer=setTimeout(()=>search(value),180);},true);
 document.addEventListener('submit',event=>{if(event.target?.id!=='search-form')return;const value=document.querySelector('#search-input')?.value||'';if(!han(value))return;event.preventDefault();event.stopImmediatePropagation();search(value,true);},true);
})();
