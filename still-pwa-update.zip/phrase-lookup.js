/* Add direct phrase lookup to the existing reading selection toolbar. */
(()=>{
 const phrase=value=>/^[A-Za-z]+(?:[\s’'-]+[A-Za-z]+)+$/.test(String(value||'').trim());
 function addButton(){const text=readingSelection?.text?.replace(/\s+/g,' ').trim()||'';if(!phrase(text))return;const actions=document.querySelector('#reading-selection-tools .selection-main-actions');if(!actions||actions.querySelector('[data-action="selection-phrase-lookup"]'))return;actions.insertAdjacentHTML('afterbegin','<button data-action="selection-phrase-lookup">'+icon('search')+'<span>查词组</span></button>');}
 function later(){setTimeout(addButton,80);}
 document.addEventListener('selectionchange',later,true);document.addEventListener('pointerup',later,true);
 document.addEventListener('click',event=>{const button=event.target.closest?.('[data-action="selection-phrase-lookup"]');if(!button)return;event.preventDefault();event.stopImmediatePropagation();const text=readingSelection?.text?.replace(/[’]/g,"'").replace(/\s+/g,' ').trim();if(!text)return;hideReadingSelection(true);lookup(text);},true);
})();
